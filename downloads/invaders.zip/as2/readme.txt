I'd reccommend using the version that is stepped down from AS3, since it's a bit cleaner and you can tweak some of the globals easier. That said, it's retrograded down, quite hastily, from my working AS3 experiment and I may have missed some things.

Hence, if you see issues, try the version in the "older working" directory.

Sorry for the fork.