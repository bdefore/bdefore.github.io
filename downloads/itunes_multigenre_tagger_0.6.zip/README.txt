iTunes Multi-Genre Tagger v0.6
http://bcdef.org/

Authors:
Buck DeFore (bdefore@gmail.com)

Credits:
Wes Rogers (633k.net) for his Last.fm Tagger which underlies much of the code
Christopher Gorvan (gorvan.com) for the icon set

Requirements:
Mac OS X 10.4 or higher

Usage:
Select some tracks in iTunes, then run IMGT and click Get Tags!

To do:
Clean up ugly Ruby error that occurs when music file is not accessible/writable.

Troubleshooting:
This application depends on Ruby which should be pre-installed with OS X at /usr/bin/ruby. If you've modified this installation it may not work.

Changelog:

0.6 -
Runs as a native OS X application, RubyOSA gem included within installation
User-configurable maximum tags
User-configurable minimum tag popularity

0.5
Initial version adapted from Last.fm Tagger for multiple genre assignments