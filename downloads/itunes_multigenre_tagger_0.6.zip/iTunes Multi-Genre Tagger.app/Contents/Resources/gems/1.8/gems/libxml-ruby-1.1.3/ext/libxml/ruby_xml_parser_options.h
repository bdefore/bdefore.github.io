/* $Id: ruby_xml_parser.h 710 2009-01-20 05:30:51Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER_OPTIONS__
#define __RXML_PARSER_OPTIONS__

#define MAX_LIBXML_FEATURES_LEN 50

extern VALUE mXMLParserOptions;

void rxml_init_parser_options();

#endif
