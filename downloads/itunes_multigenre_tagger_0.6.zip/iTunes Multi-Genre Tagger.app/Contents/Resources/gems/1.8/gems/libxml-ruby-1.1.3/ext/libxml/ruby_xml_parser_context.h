/* $Id: ruby_xml_parser_context.h 758 2009-01-25 20:36:03Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER_CONTEXT__
#define __RXML_PARSER_CONTEXT__

extern VALUE cXMLParserContext;

void rxml_init_parser_context(void);

#endif
