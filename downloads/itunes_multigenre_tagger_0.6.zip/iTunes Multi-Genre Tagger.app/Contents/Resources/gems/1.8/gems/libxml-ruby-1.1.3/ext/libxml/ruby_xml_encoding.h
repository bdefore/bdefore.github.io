/* $Id: rxml_parser.h 39 2006-02-21 20:40:16Z roscopeco $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_ENCODING__
#define __RXML_ENCODING__

extern VALUE mXMLEncoding;

void rxml_init_encoding();

#endif
