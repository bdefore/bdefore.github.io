/* $Id: ruby_xml_xinclude.h 758 2009-01-25 20:36:03Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_XINCLUDE__
#define __RXML_XINCLUDE__

extern VALUE cXMLXInclude;
extern VALUE eXMLXIncludeError;

void rxml_init_xinclude(void);

#endif
