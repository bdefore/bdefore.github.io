#ifndef __RXML_SCHEMA__
#define __RXML_SCHEMA__

#include <libxml/schemasInternals.h>
#include <libxml/xmlschemas.h>

extern VALUE cXMLSchema;

void  rxml_init_schema(void);
#endif

