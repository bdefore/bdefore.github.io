class Tagger
  @@tagged, @@skipped, @@indentical = 0, 0, 0

  def initialize
    itunes = OSA.app('iTunes')
    @selection = itunes.selection
    @artist = Artist.new
    @artists = @selection.map { |s| s.artist }.uniq.length

    $stderr.puts "#{Color.error} Please select some tracks in iTunes" if @selection.empty?
  end

  def start
    puts "#{@selection.length} tracks selected.\n#{@artists} unique artists."
    @selection.each_with_index do |track, idx|
      break if @input =~ /[aq]/
      # check if artist differs; if so, reinstantiate @artist
      if @artist.name.downcase != track.artist.strip.downcase
        @artist = Artist.new(track.artist)
        if @artist.genre == ""
          puts %{#{Color.pass} No tags found for "#{@artist.name}".}
          @@skipped += 1
          @input = 'n'
        else
          #puts "#{idx+1} out of #{@selection.length}"
          @input = confirm
        end
      end
      track.grouping = @artist.genre if @input == 'y'
    end
    puts "Done!\nTags Found:\t#{@@tagged}\nSkipped:\t#{@@skipped}\nIdentical:\t#{@@indentical}"
  end
  
  def confirm
    print %{#{Color.success} Tagging "#{@artist.name}" as "#{@artist.genre}". }
    @@tagged += 1

    # add some space when in quiet mode
    if quiet?
      puts
      return 'y'
    end

    print %{Continue? (y/n/q) }
    gets.chomp.downcase
  end

  # handles -q argument
  def quiet?
    return true if ARGV[0] == '-q'
  end
end
