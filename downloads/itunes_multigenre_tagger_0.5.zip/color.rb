class Color
  def self.pass
    "[ \e[33mPASS\e[0m ]"
  end
  
  def self.success
    "[ \e[32mSUCCESS\e[0m ]"
  end
  
  def self.error
    "[ \e[31mERROR\e[0m ]"
  end
end
