class Artist
  attr_reader :name, :genre
  
  def initialize(name='', genre='')
    @name, @genre = name, genre
    query unless name == ''
  end
  
  def query
    if GENRES.include?(@name)
      @genre = GENRES[@name]
      puts %{"#{@name}" found in local database, skipping last.fm query...}
    else
      puts %{Querying last.fm for: "#{@name}"...}
      begin
        doc = REXML::Document.new(Net::HTTP.get(URI("http://ws.audioscrobbler.com/1.0/artist/#{URI.escape(CGI.escape(@name))}/toptags.xml")))
      rescue EOFError => e
        puts "#{Color.error} Request timed out! Trying again..."
        query
      rescue Exception
        puts "Unknown error"
      end
      if doc
        @genre = '';
        arrNames = REXML::XPath.match(doc, "//toptags/tag/name")
        arrCounts = REXML::XPath.match(doc, "//toptags/tag/count")
        totalTags = arrNames.length
        if totalTags > 20
          totalTags = 20
        end
        counter = 0
        totalTags.times do 
          name = arrNames[counter]
          @genre += Integer(arrCounts[counter].text.strip) > 5 ? name.text.strip + " " : ""
          counter = counter+1
        end
      end
    end
    
    GENRES[@name] = @genre unless GENRES.include?(@name)
  end
end
