# Last.fm Tagger v1.0
#
# Author:
# wes@633k.net
#

begin require 'rubygems'; rescue LoadError; end
%W{rbosa net/http cgi rexml/document artist tagger color}.map { |i| begin require i; rescue LoadError; end }

OSA.utf8_strings = true

GENRES = {}

Tagger.new.start